
var ppm = [];
var firebase = new Firebase("pryt-pst-g5.firebaseio.com");
firebase.on('value', function (snapshot) {
  for (let i in snapshot.val().ppm) {
    //console.log(i);
    ppm.push(snapshot.val().ppm[i].valor);
  }


  ppm = ppm.slice(ppm.length - 20, ppm.length);
  drawGraph(ppm);
});

function drawGraph(ppm) {
  var labels = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];
  var ctx = document.getElementById("myChart").getContext('2d');
  var colors = [];
  for(var i =0; i < ppm.length; i++){
    var color;
    if(ppm[i]<50){color = "aquamarine";}
    else if(50<ppm[i]<100){color = 'cadetblue';}
    else if(100<ppm[i]<200){color = "blue";}
    else if(200<ppm[i]<300){color = "darkblue";}
    else if(300<ppm[i]<400){color = "chartreuse";}
    else if(400<ppm[i]<500){color = "darkolivegreen";}
    else if(500<ppm[i]){color = "darkred";}
    colors[i] = color;
  }

  var myChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: "TDS en ppm",
        labelString: "ppm",
        borderColor: "gainsboro",
        backgroundColor: "gainsboro",
        pointBackgroundColor: colors,
        pointBorderColor: colors,
        fill: false,
        data: ppm,
        yAxisID: "y-axis-ppm",
      }]
    },
    options: {
      zoomEnabled: true,
      responsive: true,
      maintainAspectRatio: false,
      hoverMode: 'index',
      stacked: false,
      title: {
        display: true,
        text: 'Ultimos 20'
      },

      scales: {
        yAxes: [{
          type: "linear",
          display: true,
          position: "left",
          id: "y-axis-ppm",
          ticks: {
            beginAtZero: true,
            suggestedMax: 50
          }

        }],
      }
    }
  });
}
